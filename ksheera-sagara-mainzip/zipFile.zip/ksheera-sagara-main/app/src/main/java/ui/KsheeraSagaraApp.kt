package com.example.ksheera_sagara.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.basicMarquee
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Divider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ksheera_sagara.R
import com.example.ksheera_sagara.viewmodel.DairyViewModel

private enum class AppPage(val title: String) {
    Dashboard("Dashboard"),
    Milk("Milk Entry"),
    Expense("Expense Entry"),
    Reports("Profit/Loss")
}

private val Meadow = Color(0xFF018A4D)
private val Leaf = Color(0xFF73C64A)
private val Milk = Color(0xFFFFF9E8)
private val Butter = Color(0xFFFFB000)
private val Soil = Color(0xFF9A4E15)
private val Ink = Color(0xFF102A22)
private val ErrorRed = Color(0xFFC62828)

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun KsheeraSagaraApp(viewModel: DairyViewModel) {
    val milkEntries by viewModel.milkEntries.collectAsState()
    val expenses by viewModel.expenses.collectAsState()
    val summary = viewModel.calculateSummary(milkEntries, expenses)

    var showIntro by remember { mutableStateOf(true) }
    var currentPage by remember { mutableStateOf(AppPage.Dashboard) }

    MaterialTheme {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        listOf(Color(0xFFFFF4C7), Color(0xFFDDF8E6), Color(0xFFEAF4FF))
                    )
                )
        ) {
            if (showIntro) {
                IntroPage(onEnterClick = { showIntro = false })
                return@Box
            }

            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .verticalScroll(rememberScrollState())
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                AppHeader(
                    currentPage = currentPage,
                    onPageSelected = { currentPage = it }
                )

                Text(
                    text = "Fresh milk records  |  feed and medicine expenses  |  dairy farming profit and loss calculator  |  grow your farm with clear numbers",
                    modifier = Modifier
                        .fillMaxWidth()
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color(0xFF153D2A))
                        .basicMarquee(iterations = Int.MAX_VALUE)
                    .padding(horizontal = 12.dp, vertical = 10.dp),
                    color = Color.White,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold
                )

                DashboardStrip(
                    income = summary.totalIncome,
                    expense = summary.totalExpense,
                    profit = summary.netProfit,
                    milkCount = milkEntries.size,
                    expenseCount = expenses.size
                )

                when (currentPage) {
                    AppPage.Dashboard -> DashboardPage(
                        onMilkClick = { currentPage = AppPage.Milk },
                        onExpenseClick = { currentPage = AppPage.Expense },
                        onReportsClick = { currentPage = AppPage.Reports }
                    )

                    AppPage.Milk -> MilkEntryPage(
                        viewModel = viewModel,
                        onSaved = { currentPage = AppPage.Expense }
                    )
                    AppPage.Expense -> ExpenseEntryPage(
                        viewModel = viewModel,
                        onSaved = { currentPage = AppPage.Reports }
                    )
                    AppPage.Reports -> ReportsPage(
                        income = summary.totalIncome,
                        expense = summary.totalExpense,
                        profit = summary.netProfit,
                        milkCount = milkEntries.size,
                        expenseCount = expenses.size,
                        onClearClick = { viewModel.clearAllData() }
                    )
                }
            }
        }
    }
}

@Composable
private fun IntroPage(onEnterClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(18.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        Spacer(Modifier.height(14.dp))
        Text(
            text = "WELCOME TO",
            color = Color(0xFF0A6140),
            fontSize = 18.sp,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center
        )
        Text(
            text = "KSHEERA SAGARA",
            color = Color(0xFF062E4F),
            fontSize = 36.sp,
            fontWeight = FontWeight.Black,
            textAlign = TextAlign.Center
        )
        Text(
            text = "Dairy Farming Profit & Loss Calculator",
            color = Color(0xFF0A6140),
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            textAlign = TextAlign.Center
        )

        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = Milk),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            shape = RoundedCornerShape(8.dp)
        ) {
            Image(
                painter = painterResource(id = R.drawable.ksheera_sagara_intro_small),
                contentDescription = "Ksheera Sagara dairy farm intro image",
                modifier = Modifier
                    .fillMaxWidth()
                    .height(340.dp)
                    .padding(10.dp)
                    .clip(RoundedCornerShape(8.dp)),
                contentScale = ContentScale.Fit
            )
        }

        Text(
            text = "Manage milk income, feed costs, medicine, labor, and monthly profit in one farmer-friendly dashboard.",
            color = Ink,
            fontSize = 15.sp,
            fontWeight = FontWeight.SemiBold,
            textAlign = TextAlign.Center
        )

        Button(
            onClick = onEnterClick,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF062E4F)),
            shape = RoundedCornerShape(8.dp),
            contentPadding = PaddingValues(vertical = 16.dp)
        ) {
            Text("Enter Main Dashboard", fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun AppHeader(
    currentPage: AppPage,
    onPageSelected: (AppPage) -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.Transparent),
        elevation = CardDefaults.cardElevation(defaultElevation = 0.dp),
        shape = RoundedCornerShape(8.dp)
    ) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .clip(RoundedCornerShape(8.dp))
                .background(
                    Brush.horizontalGradient(
                        colors = listOf(Color(0xFF003B2F), Color(0xFF00A66A), Color(0xFFFFB000))
                    )
                )
                .padding(16.dp)
        ) {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FarmBadge()
                    Spacer(Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "KSHEERA SAGARA",
                            color = Color.White,
                            fontSize = 30.sp,
                            fontWeight = FontWeight.Black
                        )
                        Text(
                            text = "Smart Dairy Farming Profit & Loss Calculator",
                            color = Color(0xFFFFF5BD),
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AppPage.values().forEach { page ->
                        val selected = page == currentPage
                        Button(
                            onClick = { onPageSelected(page) },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (selected) Color.White else Color(0xFF003B2F).copy(alpha = 0.35f),
                                contentColor = if (selected) Ink else Color.White
                            ),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 4.dp, vertical = 10.dp)
                        ) {
                            Text(
                                text = page.title,
                                fontSize = 12.sp,
                                maxLines = 1,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun FarmBadge() {
    Box(
        modifier = Modifier
            .size(58.dp)
            .clip(CircleShape)
            .background(Milk),
        contentAlignment = Alignment.Center
    ) {
        Text("KS", color = Meadow, fontSize = 22.sp, fontWeight = FontWeight.Black)
    }
}

@Composable
private fun DashboardStrip(
    income: Double,
    expense: Double,
    profit: Double,
    milkCount: Int,
    expenseCount: Int
) {
    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            SummaryTile("Income", formatMoney(income), Meadow, Modifier.weight(1f))
            SummaryTile("Expenses", formatMoney(expense), Soil, Modifier.weight(1f))
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            SummaryTile("Net Result", formatMoney(profit), if (profit >= 0) Meadow else ErrorRed, Modifier.weight(1f))
            SummaryTile("Records", "$milkCount milk / $expenseCount cost", Color(0xFF286C7A), Modifier.weight(1f))
        }
    }
}

@Composable
private fun SummaryTile(title: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Card(
        modifier = modifier,
        colors = CardDefaults.cardColors(containerColor = accent),
        elevation = CardDefaults.cardElevation(defaultElevation = 5.dp),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Box(
                modifier = Modifier
                    .width(38.dp)
                    .height(4.dp)
                    .clip(RoundedCornerShape(8.dp))
                    .background(Color.White.copy(alpha = 0.85f))
            )
            Text(title, color = Color.White.copy(alpha = 0.88f), fontSize = 12.sp, fontWeight = FontWeight.Bold)
            Text(value, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Black)
        }
    }
}

@Composable
private fun DashboardPage(
    onMilkClick: () -> Unit,
    onExpenseClick: () -> Unit,
    onReportsClick: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(16.dp)) {
        ImageFeatureCard(
            title = "Smart Dairy Dashboard",
            subtitle = "Track milk sales, animal care costs, and daily farm profit in one clean place.",
            art = FarmArt.Farm
        )

        Row(horizontalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
            ActionCard("Add Milk", "Cow and buffalo milk income", FarmArt.Cow, onMilkClick, Modifier.weight(1f))
            ActionCard("Add Expense", "Feed, medicine, vet and labor", FarmArt.Buffalo, onExpenseClick, Modifier.weight(1f))
        }

        Button(
            onClick = onReportsClick,
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF184D34)),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("Open Profit / Loss Report")
        }
    }
}

@Composable
private fun ActionCard(
    title: String,
    subtitle: String,
    art: FarmArt,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        onClick = onClick,
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            FarmIllustration(art, Modifier.height(96.dp).fillMaxWidth())
            Text(title, color = Ink, fontWeight = FontWeight.Bold, fontSize = 17.sp, textAlign = TextAlign.Center)
            Text(subtitle, color = Color(0xFF667064), fontSize = 12.sp, textAlign = TextAlign.Center)
        }
    }
}

@Composable
private fun ImageFeatureCard(title: String, subtitle: String, art: FarmArt) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
            FarmIllustration(art, Modifier.fillMaxWidth().height(170.dp))
            Column(Modifier.padding(start = 16.dp, end = 16.dp, bottom = 16.dp)) {
                Text(title, color = Ink, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold)
                Spacer(Modifier.height(4.dp))
                Text(subtitle, color = Color(0xFF59645A), fontSize = 14.sp)
            }
        }
    }
}

@Composable
private fun MilkEntryPage(viewModel: DairyViewModel, onSaved: () -> Unit) {
    var liters by remember { mutableStateOf("") }
    var fat by remember { mutableStateOf("") }
    var snf by remember { mutableStateOf("") }
    var rate by remember { mutableStateOf("") }

    EntryShell("Milk Collection", "Record cow or buffalo milk and calculate income automatically.", FarmArt.Cow) {
        NumberField(liters, { liters = it }, "Liters")
        NumberField(fat, { fat = it }, "Fat")
        NumberField(snf, { snf = it }, "SNF")
        NumberField(rate, { rate = it }, "Rate per liter")

        Button(
            onClick = {
                viewModel.addMilkEntry(
                    liters = liters.toDoubleOrNull() ?: 0.0,
                    fat = fat.toDoubleOrNull() ?: 0.0,
                    snf = snf.toDoubleOrNull() ?: 0.0,
                    ratePerLiter = rate.toDoubleOrNull() ?: 0.0
                )
                liters = ""
                fat = ""
                snf = ""
                rate = ""
                onSaved()
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Meadow),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("Save Milk Entry")
        }
    }
}

@Composable
private fun ExpenseEntryPage(viewModel: DairyViewModel, onSaved: () -> Unit) {
    var category by remember { mutableStateOf("Feed") }
    var amount by remember { mutableStateOf("") }

    EntryShell("Farm Expenses", "Add feed, medicine, vet, labor, transport, or other dairy costs.", FarmArt.Buffalo) {
        OutlinedTextField(
            value = category,
            onValueChange = { category = it },
            label = { Text("Category") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )
        NumberField(amount, { amount = it }, "Amount")

        Button(
            onClick = {
                viewModel.addExpense(
                    category = category.ifBlank { "General" },
                    amount = amount.toDoubleOrNull() ?: 0.0
                )
                amount = ""
                onSaved()
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Soil),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("Save Expense")
        }
    }
}

@Composable
private fun ReportsPage(
    income: Double,
    expense: Double,
    profit: Double,
    milkCount: Int,
    expenseCount: Int,
    onClearClick: () -> Unit
) {
    EntryShell("Profit / Loss Report", "Your dairy business position based on saved records.", FarmArt.Farm) {
        ReportLine("Total milk income", formatMoney(income))
        ReportLine("Total farm expense", formatMoney(expense))
        ReportLine("Milk records", milkCount.toString())
        ReportLine("Expense records", expenseCount.toString())
        Divider(color = Color(0xFFE2DED4))
        ReportLine(
            title = if (profit >= 0) "Net profit" else "Net loss",
            value = formatMoney(profit),
            valueColor = if (profit >= 0) Meadow else ErrorRed
        )
        OutlinedButton(
            onClick = onClearClick,
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(8.dp)
        ) {
            Text("Clear All Data")
        }
    }
}

@Composable
private fun EntryShell(
    title: String,
    subtitle: String,
    art: FarmArt,
    content: @Composable ColumnScope.() -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        shape = RoundedCornerShape(8.dp)
    ) {
        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            FarmIllustration(art, Modifier.fillMaxWidth().height(150.dp))
            Text(title, color = Ink, fontSize = 23.sp, fontWeight = FontWeight.ExtraBold)
            Text(subtitle, color = Color(0xFF607064), fontSize = 14.sp)
            content()
        }
    }
}

@Composable
private fun NumberField(value: String, onValueChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        label = { Text(label) },
        modifier = Modifier.fillMaxWidth(),
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal)
    )
}

@Composable
private fun ReportLine(title: String, value: String, valueColor: Color = Ink) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(title, color = Color(0xFF5E685F), fontWeight = FontWeight.Medium)
        Text(value, color = valueColor, fontWeight = FontWeight.Bold, fontSize = 18.sp)
    }
}

private enum class FarmArt {
    Cow,
    Buffalo,
    Farm
}

@Composable
private fun FarmIllustration(art: FarmArt, modifier: Modifier = Modifier) {
    val image = when (art) {
        FarmArt.Cow -> R.drawable.real_dairy_cow
        FarmArt.Buffalo -> R.drawable.real_dairy_buffalo
        FarmArt.Farm -> R.drawable.real_dairy_farm
    }
    Image(
        painter = painterResource(id = image),
        contentDescription = art.name,
        modifier = modifier
            .clip(RoundedCornerShape(8.dp))
            .background(Color(0xFFEAF5DD)),
        contentScale = ContentScale.Crop
    )
}

private fun DrawScope.drawSkyAndField() {
    drawRect(
        brush = Brush.verticalGradient(listOf(Color(0xFFBFE4F2), Color(0xFFEAF5DD))),
        size = size
    )
    drawCircle(Color(0xFFFFD66B), radius = size.minDimension * 0.12f, center = Offset(size.width * 0.82f, size.height * 0.22f))
    drawRoundRect(
        color = Color(0xFF8FCB62),
        topLeft = Offset(0f, size.height * 0.58f),
        size = Size(size.width, size.height * 0.42f),
        cornerRadius = CornerRadius(18f, 18f)
    )
}

private fun DrawScope.drawCow() {
    val w = size.width
    val h = size.height
    drawRoundRect(Color.White, Offset(w * 0.22f, h * 0.43f), Size(w * 0.48f, h * 0.25f), CornerRadius(26f, 26f))
    drawCircle(Color.White, radius = h * 0.13f, center = Offset(w * 0.71f, h * 0.45f))
    drawCircle(Color.Black, radius = h * 0.045f, center = Offset(w * 0.38f, h * 0.51f))
    drawCircle(Color.Black, radius = h * 0.05f, center = Offset(w * 0.53f, h * 0.57f))
    drawCircle(Color.Black, radius = h * 0.018f, center = Offset(w * 0.75f, h * 0.42f))
    drawRect(Soil, Offset(w * 0.29f, h * 0.66f), Size(w * 0.05f, h * 0.18f))
    drawRect(Soil, Offset(w * 0.58f, h * 0.66f), Size(w * 0.05f, h * 0.18f))
    drawRoundRect(Color(0xFFFFD2C2), Offset(w * 0.67f, h * 0.48f), Size(w * 0.15f, h * 0.09f), CornerRadius(18f, 18f))
    drawLine(Color(0xFF3E2A17), Offset(w * 0.23f, h * 0.49f), Offset(w * 0.13f, h * 0.36f), strokeWidth = 5f)
}

private fun DrawScope.drawBuffalo() {
    val w = size.width
    val h = size.height
    drawRoundRect(Color(0xFF3C3C3C), Offset(w * 0.19f, h * 0.45f), Size(w * 0.55f, h * 0.25f), CornerRadius(28f, 28f))
    drawCircle(Color(0xFF303030), radius = h * 0.14f, center = Offset(w * 0.73f, h * 0.46f))
    drawLine(Color(0xFFE8D8A8), Offset(w * 0.66f, h * 0.35f), Offset(w * 0.54f, h * 0.25f), strokeWidth = 7f)
    drawLine(Color(0xFFE8D8A8), Offset(w * 0.80f, h * 0.35f), Offset(w * 0.93f, h * 0.25f), strokeWidth = 7f)
    drawCircle(Color.White, radius = h * 0.018f, center = Offset(w * 0.76f, h * 0.42f))
    drawRect(Color(0xFF252525), Offset(w * 0.30f, h * 0.68f), Size(w * 0.06f, h * 0.17f))
    drawRect(Color(0xFF252525), Offset(w * 0.60f, h * 0.68f), Size(w * 0.06f, h * 0.17f))
    drawLine(Color(0xFF252525), Offset(w * 0.20f, h * 0.52f), Offset(w * 0.10f, h * 0.40f), strokeWidth = 6f)
}

private fun DrawScope.drawFarmScene() {
    val w = size.width
    val h = size.height
    val roof = Path().apply {
        moveTo(w * 0.18f, h * 0.50f)
        lineTo(w * 0.36f, h * 0.28f)
        lineTo(w * 0.54f, h * 0.50f)
        close()
    }
    drawPath(roof, Color(0xFFB84A2A))
    drawRoundRect(Color(0xFFFFF3D4), Offset(w * 0.23f, h * 0.49f), Size(w * 0.26f, h * 0.26f), CornerRadius(8f, 8f))
    drawRect(Soil, Offset(w * 0.33f, h * 0.61f), Size(w * 0.08f, h * 0.14f))
    drawLine(Leaf, Offset(w * 0.62f, h * 0.75f), Offset(w * 0.88f, h * 0.55f), strokeWidth = 7f)
    drawLine(Leaf, Offset(w * 0.63f, h * 0.83f), Offset(w * 0.91f, h * 0.63f), strokeWidth = 7f)
    drawLine(Leaf, Offset(w * 0.59f, h * 0.66f), Offset(w * 0.83f, h * 0.47f), strokeWidth = 7f)
    drawCircle(Color.White, radius = h * 0.055f, center = Offset(w * 0.70f, h * 0.46f))
    drawCircle(Color(0xFF303030), radius = h * 0.05f, center = Offset(w * 0.78f, h * 0.48f))
}

private fun formatMoney(value: Double): String = "Rs. %.2f".format(value)
